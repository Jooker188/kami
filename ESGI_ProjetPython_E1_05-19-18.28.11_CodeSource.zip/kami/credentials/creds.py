user_pseudo = "JookerESGI"
user_email = "remydionisiopro@gmail.com"
user_passwd = "AZerty123/*-+=-"
