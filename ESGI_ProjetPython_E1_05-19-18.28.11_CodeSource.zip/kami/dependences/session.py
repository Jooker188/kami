import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning


''' ------------------------------------ DESCRIPTION ------------------------------------

Ce fichier contient la fonction set_session() qui génère une session requests configurée avec des options de vérification et de sécurité. Cette session peut être utilisée pour effectuer des requêtes HTTP.

'''

'''
Cette fonction génère une session requests en configurant certaines options de vérification et de sécurité. 
Elle retourne la session nouvellement créée.
'''
def set_session():
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    session = requests.session()
    session.verify = False
    
    return session