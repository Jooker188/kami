import urllib.parse

''' ------------------------------------ DESCRIPTION ------------------------------------

Ce fichier contient des fonctions utilitaires qui offrent des fonctionnalités pratiques pour 
la gestion des paramètres POST, la manipulation de fichiers et la détection de captchas lors des opérations de requête

'''

'''
Cette fonction lit un fichier contenant des paramètres POST et les parse pour les stocker dans un dictionnaire. 
Elle retourne le dictionnaire contenant les paramètres POST.
'''
def parse_post_args():
    file = 'logs/post_params.log'
    clean = clean_post_params(file)
    if clean != None:
        with open(file, 'r') as f:
            post_params = f.read()

        args = post_params.split('&')
        dico_post = {}

        for arg in args:
            name, value = arg.split('=')
            dico_post[name] = value

        return dico_post
    else:
        return None


'''
Cette fonction nettoie les paramètres POST dans un fichier log. 
Elle lit le contenu du fichier et supprime les requêtes supplémentaires, ne laissant que la première requête. 
Elle retourne le contenu nettoyé du fichier.
'''
def clean_post_params(log_file_path):
    try:
        with open(log_file_path, 'r') as f:
            raw_data = f.read()
    except:
        return None

    # Cherche le premier saut de ligne double
    end_index = raw_data.find('\n\n')

    if end_index == -1:
        return raw_data  # Aucun saut de ligne double trouvé, retourne le contenu brut

    # Retourne uniquement la première requête
    return raw_data[:end_index]


'''
Cette fonction extrait le nom de domaine d'une URL donnée et le sauvegarde dans un fichier spécifié par path. 
sElle écrit le nom de domaine dans le fichier.
'''
def create_domain_file(url, path):
    parsed_url = urllib.parse.urlparse(url)
    domain = parsed_url.netloc
    with open(path, 'w') as f:
        f.write(domain)


'''
Cette fonction lit le contenu d'un fichier spécifié par file_path et retourne le contenu sous forme de chaîne de caractères.
'''
def read_file_content(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    return content

