from datetime import datetime, timedelta
from colorama import Fore, Style
import time

''' ------------------------------------ DESCRIPTION ------------------------------------

Ce fichier contient des fonctions qui vont améliorer l'expérience utilisateurs, et des fonctions utiles pour le code

'''


intro = """

                                        
              {1}   
              
                     
        {2}          {0}
"""

version = "{0.0.1#stable}"
website = "https://remydionisio.fr"
bouddha = r'''
              _oo0oo_          |  /
             o8888888o         | /
             88" . "88         |/
             (| -_- |)         |\
             0\  =  /0         | \         /\
           ___/`---'\___       |  \       /  \
         .' \\|     |// '.     |   \     /    \
        / \\|||  :  |||// \             /------\       
       / _||||| -:- |||||_ \           /        \
      |   | \\\  -  /// |   |         /          \
      | \_|  ''\---/''  |_/ |                |\         /|
      \  .-\__  '-'  __/-.  /                | \       / |
    ___'. .'  /--.--\  `. .'___              |  \     /  |   
 ."" '<  `.___\_<|>_/___.' >' "".            |   \   /   |     |
| | :  `- \`.;`\ _ /`;.`/ - ` : | |          |    \-/    |     |
\  \ `_.   \_ __\ /__ _/   .-` /  /          |           |     |
====`-.____`.___ \_____/___.-`___.-'====                       |
              `=---='                                          |
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^                       |
          佛祖保佑       永无BUG                              
'''

fin = "\nSee you, Bye !\n"

def get_heure():
    heure_actuelle = datetime.now()
    delta = heure_actuelle + timedelta(hours=6)
    heure_formattee = delta.strftime("[%H:%M:%S]")
    return heure_formattee

def get_cat_info(info):
    if info == 'info':
        return Fore.YELLOW + " [INFO]"
    elif info == 'user':
        return Fore.GREEN + " [USER]"
    if info == 'found':
        return Fore.RED + " [FOUND]"
    
def forme(info):
    return Fore.MAGENTA + get_heure() + get_cat_info(info) + Style.RESET_ALL

def wait(n):
    return time.sleep(n)