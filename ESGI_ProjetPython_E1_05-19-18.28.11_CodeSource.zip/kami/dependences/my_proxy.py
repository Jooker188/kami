from mitmproxy import http
import os
from request_utils import read_file_content

''' ------------------------------------ DESCRIPTION ------------------------------------
Ce fichier contient une classe FilterPostRequests qui est utilisée pour filtrer les requêtes POST dans le proxy. 
Il importe les modules nécessaires et définit la classe qui vérifie si une requête est de méthode POST et si l'hôte de la requête correspond à l'URL spécifiée. 
Si ces conditions sont remplies, le contenu de la requête est enregistré dans post_params.log. 
On va aussi récuperer l'URL de la target dans le fichier url.log. 
Les instances de la classe FilterPostRequests sont ensuite ajoutées aux addons du proxy.

'''


class FilterPostRequests:

    def __init__(self, url):
        self.url = url

    def request(self, flow: http.HTTPFlow) -> None:
        if flow.request.method == "POST" and flow.request.host == self.url:
            text_request = flow.request.get_text()
            if "-digest256;" not in text_request and "&" in text_request and text_request[0] != "{" and text_request[-1] != "}":
                with open("logs/post_params.log", "a") as f:
                    f.write(text_request)
                    f.write("\n\n")

if os.path.exists("logs/post_params.log"):
    os.remove("logs/post_params.log")

url = read_file_content("logs/url.log").strip()

addons = [
    FilterPostRequests(url)
]
