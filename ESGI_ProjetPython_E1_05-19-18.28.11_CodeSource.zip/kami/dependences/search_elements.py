from selenium.webdriver.common.by import By


''' ------------------------------------ DESCRIPTION ------------------------------------

Ce fichier regroupe les fonctions liées à la recherche d'éléments dans une page web. 
Les fonctions permettent de trouver des éléments spécifiques tels que des champs de login, de mot de passe et des boutons de soumission. 
Elles facilitent l'interaction avec les formulaires et les pages web.

'''

'''
Cette fonction recherche un élément input dans la page web en utilisant différents sélecteurs tels que l'ID, le nom, la classe et le XPath. 
Elle prend en compte le type d'élément recherché, qui peut être "login" ou "password". 
Elle retourne l'élément input s'il est trouvé, sinon elle retourne None.
'''
def search_login_or_password(driver, tab, x):

    for e in tab:
        id_found = rewrite_find_element(driver, By.ID, e)
        if id_found != None and id_found.tag_name == "input": return id_found

        name_found = rewrite_find_element(driver, By.NAME, e)
        if name_found != None and name_found.tag_name == "input": return name_found

        class_name_found = rewrite_find_element(driver, By.CLASS_NAME, e)
        if class_name_found != None and class_name_found.tag_name == "input": return class_name_found

        xpath_found = xpath_search_closest_label(driver, e)
        if xpath_found != None and xpath_found.tag_name == "input": return xpath_found

    if x == "login":
        required_found = rewrite_find_element(driver, By.XPATH, "//*[@required]")
        if required_found != None and required_found.tag_name == "input": return required_found
    elif x == "password":
        password_type_found = rewrite_find_element(driver, By.XPATH, "//input[@type='password']")
        if password_type_found != None and password_type_found.tag_name == "input": return password_type_found

    return None

'''
Cette fonction recherche un bouton de soumission (submit) dans la page web en utilisant différents sélecteurs tels que le type, le XPath et le texte. 
Elle prend en compte une liste de textes acceptés pour le bouton de soumission. 
Elle retourne l'élément bouton de soumission s'il est trouvé, sinon elle retourne None
'''
def search_submit(driver, tab):
    type_autorise = ['button', 'input', 'a']
    selecteur_autorise = ["[@onclick]", "[@type='submit']"]

    expressions = []
    for t in type_autorise:
        for s in selecteur_autorise:
            expr = "//" + t + s
            expressions.append(expr)

    for expr in expressions:
        found = rewrite_find_element(driver, By.XPATH, expr)
        if found != None:
            return found

    type_autorise_last = ['button', 'span', 'a', 'input']

    # Recherche des éléments bouton contenant du texte spécifique
    for text in tab:
        for element_type in type_autorise_last:
            expr = f"*//{element_type}[contains(., '{text}')]"
            found = rewrite_find_element(driver, By.XPATH, expr)
            if found is not None:
                return found
    
    return None

'''
Cette fonction est une version réécrite de la méthode find_element() du driver WebDriver. 
Elle cherche un élément en utilisant la méthode et l'élément spécifiés. 
Si l'élément n'est pas trouvé, elle retourne None.
'''
def rewrite_find_element(driver, methode, e):
    try:
        element = driver.find_element(methode, e)
        return element
    except:
        return None



'''
Cette fonction recherche l'élément input le plus proche d'un label spécifié dans la page web en utilisant le XPath. 
Elle retourne l'élément input s'il est trouvé, sinon elle retourne None.
'''
def xpath_search_closest_label(driver, label_text):
    try:
        label_element = driver.find_element(By.XPATH, "//label[contains(text(), '"+ label_text +"')]")
        xpath_found = label_element.find_elements(By.XPATH, ".//following::*[self::input][1]")
   
        if len(xpath_found) > 0:
            return xpath_found[0]
        else:
            return None
    except:
        return None


'''
Cette fonction utilise la fonction search_login_or_password() pour rechercher un champ de saisie de login dans la page web. 
Elle retourne l'élément input du login s'il est trouvé, sinon elle retourne None.
'''
def find_login(driver):
    id_tab = ["email", "Email", "EMAIL",
              "id", "Id", "ID",
              "username", "Username", "USERNAME",
              "login", "Login", "LOGIN",
              "user", "User", "USER",
              "identifiant", "Identifiant", "IDENTIFIANT",
              "authentication_login", "Authentication_login"
    ]
    
    email_input = search_login_or_password(driver, id_tab, "login")

    return email_input



'''
Cette fonction utilise la fonction search_login_or_password() pour rechercher un champ de saisie de mot de passe dans la page web. 
Elle retourne l'élément input du mot de passe s'il est trouvé, sinon elle retourne None.
'''
def find_password(driver):
    pwd_tab = ["pass", "Pass", "PASS",
              "password", "Password", "PASSWORD",
              "motdepasse", "mot_de_passe", "Motdepasse",
              "authentication_password" "Authentication_password"
    ]

    pwd_input = search_login_or_password(driver, pwd_tab, "password")

    return pwd_input




'''
Cette fonction utilise la fonction search_submit() pour rechercher un bouton de soumission dans la page web. 
Elle retourne l'élément bouton de soumission s'il est trouvé, sinon elle retourne None.
'''
def find_submit(driver):
    text_accepte = ["Log In", "login", "login", "Log in","log in", "log", 
                    "LOG IN", "connecter", "Se connecter","connect","authentifier", "Sign", 
                    "valider", "VALIDER","Valider", "Envoyer", "ENVOYER", 
                    "Submit", "SUBMIT"]

    submit_button = search_submit(driver, text_accepte)

    return submit_button
