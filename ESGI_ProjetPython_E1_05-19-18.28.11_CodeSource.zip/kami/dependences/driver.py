import platform
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from dependences.utils import *

''' ------------------------------------ DESCRIPTION ------------------------------------

 Ce fichier contient la fonction set_driver() qui génère un driver pour le navigateur Firefox. 
 Le driver est configuré en fonction du système d'exploitation et des options spécifiées. 
 Il peut être utilisé pour automatiser des interactions avec des sites web à travers le navigateur Firefox.

 '''

'''
Cette fonction génère un driver pour le navigateur Firefox en fonction du système d'exploitation. 
Elle configure également le proxy et les options du driver, telles que le user-agent. 
Elle retourne le driver Firefox configuré.
'''
def set_driver(port):
    options = Options()
    options.binary_location = ''

    # Déterminer le système d'exploitation
    system = platform.system()
    if system == 'Windows':
        options.binary_location = r'C:\Program Files\Mozilla Firefox\firefox.exe'
        executable_path = "geckodriver.exe"
    elif system == 'Linux':
        executable_path = "/usr/bin/geckodriver"

    print(forme("info") + " Chargement du driver en cours ")
        
    # configuration du proxy
    proxy = "127.0.0.1"

    options = webdriver.FirefoxOptions()
    options.set_preference("network.proxy.type", 1)
    options.set_preference("network.proxy.http", proxy)
    options.set_preference("network.proxy.http_port", port)
    options.set_preference("network.proxy.ssl", proxy)
    options.set_preference("network.proxy.ssl_port", port)
    options.set_preference("general.useragent.override", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0")
    #options.headless = True

    return webdriver.Firefox(executable_path=executable_path, options=options)
