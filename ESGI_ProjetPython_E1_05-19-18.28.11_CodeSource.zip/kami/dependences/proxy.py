import platform
import subprocess
import os
import mitmproxy

''' ------------------------------------ DESCRIPTION ------------------------------------

Ce fichier contient les fonctions start_proxy(port) et kill_proxy(). 
La fonction start_proxy(port) démarre un proxy mitmproxy sur le port spécifié, tandis que la fonction kill_proxy() arrête le proxy en cours d'exécution. 
Ces fonctions peuvent être utilisées pour capturer et manipuler le trafic réseau lors des interactions avec des sites web.

'''

'''
Cette fonction démarre un proxy mitmproxy en spécifiant le port donné en paramètre. 
Elle détecte le système d'exploitation et utilise les commandes appropriées pour démarrer le proxy. 
Elle retourne 1 si le démarrage est réussi, sinon elle retourne None.
'''
def start_proxy(port):
    system = platform.system()
    try:
        if system == "Windows":
            subprocess.Popen(["start", "/B", "mitmproxy", "-s", "my_proxy.py", "-p", str(port)])
        else:
            os.system('gnome-terminal -- mitmproxy -s dependences/my_proxy.py -p' + str(port))
        return 1
    except:
        return None

'''
Cette fonction arrête le proxy mitmproxy en utilisant les commandes appropriées en fonction du système d'exploitation.
'''
def kill_proxy():
    system = platform.system()
    if system == "Linux":
        os.system("pkill mitmproxy")
    else:
        print()
        #proxy_process.terminate()

