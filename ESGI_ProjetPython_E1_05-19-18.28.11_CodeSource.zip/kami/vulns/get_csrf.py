import re
from bs4 import BeautifulSoup
from dependences.utils import *
from dependences.proxy import *
from dependences.session import *
from dependences.driver import *
from credentials.creds import *
from dependences.request_utils import *
from dependences.search_elements import *
from credentials import *
from urllib.parse import urlparse
import urllib.parse
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

''' ------------------------------------ DESCRIPTION ------------------------------------

Ce fichier effectue des opérations de détection de vulnérabilités CSRF sur une page web cible. 
Il utilise des dépendances telles que re, BeautifulSoup et des modules personnalisés. 
Le script utilise Selenium pour contrôler un navigateur, interagir avec le formulaire de connexion et envoyer des requêtes POST pour par la suite faire des opérations avec les parametres récupérés. 
Il cherche des tokens anti-CSRF dans le code source de la page et les compare aux tokens envoyés dans les requêtes. Le script détecte les vulnérabilités de réutilisation de token CSRF, de mauvais token CSRF, de suppression de token CSRF et de passage par la méthode GET. 
Enfin, il affiche les résultats à l'utilisateur

'''

def get_csrf(session,  target, page_type):

    port = 8095

    print(forme("info") + " Lancement du proxy")
    proxy = start_proxy(port)
    
    if proxy != None:
        print(forme("info") + " Proxy démarré avec succès")
    else:
        print(forme("info") + " Impossible de démarrer le proxy")
        return None

    #lancement du driver connecté au proxy
    driver = set_driver(port)
    driver.maximize_window()
    wait(2)

    driver.get(target)
    print(forme("info") + " Page cible chargée avec succès")

    wait(2)

    if page_type == "connexion":

        #recherche de l'input login + remplisage avec faux login
        login = find_login(driver)
        if login != None:
            login.send_keys("test@gmail.com")
            print(forme("info") + " Login input trouvé")
        else:
            print(forme("info") + " Login input introuvable")
            driver.quit()
            kill_proxy()
            return None

        wait(2)

        #recherche de l'input login + remplisage avec faux psswd
        mdp = find_password(driver)
        if mdp != None:
            mdp.send_keys("Test01*/-*+^")
            print(forme("info") + " Password input trouvé")
        else:
            print(forme("info") + " Password input introuvable")
            driver.quit()
            kill_proxy()
            return None

        wait(2)

        #au cas ou y'a un capcha google visible
        try:
            frame_locator = (By.XPATH, "//iframe[starts-with(@name, 'a-') and starts-with(@src, 'https://www.google.com/recaptcha')]")
            frame = WebDriverWait(driver, 10).until(EC.frame_to_be_available_and_switch_to_it(frame_locator))
            checkbox_locator = (By.ID, "recaptcha-anchor")
            checkbox_element = WebDriverWait(driver, 10).until(EC.visibility_of_element_located(checkbox_locator))
            checkbox_element.click()
            wait(2)
        except:
            pass


        #recherche du boutton de soumission + click
        submit = find_submit(driver)
        if submit != None:
            try:
                submit.click()
            except:
                driver.execute_script("arguments[0].click();", submit)
            print(forme("info") + " Submit button trouvé")

        else:
            print(forme("info") + " Submit button introuvable")
            driver.quit()
            kill_proxy()
            return None

        wait(0.5)
        
        #on ajoute les params statique dans le code source dans la requete post finale
        args_a_envoyer = parse_post_args()
        if args_a_envoyer == None:
            print(forme("info") + " Aucune requête provenant de l'url source n'est passé par le proxy.")
            return

        req_1 = args_a_envoyer

        code_source = BeautifulSoup(driver.page_source, 'html.parser')
        inputs = code_source.find_all("input")

        #minimum 3 chiffres, 3 lettres min ou maj, 1 caractère special
        token_pattern = r'^(?=.*[a-zA-Z]{3,})(?=.*\d{3,})(?=.*[!@#$%^&*()\-_=+{};:,<.>])[a-zA-Z\d!@#$%^&*()\-_=+{};:,<.>]+$'
        tokens = {}

        print(forme("info") + " Recherche de vulnérabilités en cours...")

        for inputt in inputs:
            name = inputt.get("name")
            type_ = inputt.get("type")
            value = inputt.get("value")

            if name and name in args_a_envoyer and type_ == "hidden":
                if name not in tokens and re.search(token_pattern, value):
                    tokens[name] = value

                if args_a_envoyer.get(name) == value and re.search(token_pattern, value): #si la valeur du token dans la requete est egale a la valeur du token du meme nom
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Réutilisation du jeton CSRF (" + name  +")")

                try:
                    if value == None and re.search(token_pattern, args_a_envoyer.get(name)) or int(len(str(args_a_envoyer.get(name))) > 1000): #si la valeur du token dans la requete est vide dans le code source
                        print(forme("found") + " Défense Capcha détecté : " + name)                                                             #ou si la valeur contient plus de 1000 caracteres (que des tokens)
                        print(forme("info") + " Impossible d'avancer plus loin")
                        driver.quit()
                        kill_proxy()
                        return
                except TypeError:
                    pass

                args_a_envoyer[name] = value
        
        if len(tokens) == 0:
            print(forme("found") + " Vulnérabilité trouvée : Absence de jeton CSRF (" + name  +")")

        print("\n" + forme("info") + " ----------------------- Liste des paramètres POST ----------------------- \n")

        for key in args_a_envoyer.items():
            print(key)

        print("\n" + forme("info") + " Vous devez choisir le couple login/password à remplacer :")
        input_arg = input(forme("user") + " Input paramètre : ")
        psswd_arg = input(forme("user") + " Password paramètre : ")

        #récupération des creds du compte test
        user_appelation = input(forme("user") + " Connexion avec pesudo ou email : ")
        if user_appelation == 'pesudo':
            user_login = user_pseudo
        elif user_appelation == 'email':
            user_login = user_email

        #remplacement des mauvais creds par les bons
        args_a_envoyer[input_arg] = user_login
        args_a_envoyer[psswd_arg] = user_passwd

        #envoie de la requete bonne
        req_success = session.post(target,args_a_envoyer)
        req_success_response = req_success.content

        for token, value in tokens.items():
            args_a_envoyer_copy = args_a_envoyer.copy()

            #envoie de la requete avec token faux
            args_a_envoyer_copy[token] = "012ABCabc/*-"
            req_with_bad_token = session.post(target, args_a_envoyer_copy)
            req_with_bad_token_response = req_with_bad_token.content

            #envoie de la requete sans le token
            del args_a_envoyer_copy[token]
            req_without_token = session.post(target, args_a_envoyer_copy)
            req_without_token_response = req_without_token.content

            #envoie de la requete sans le token via GET méthode
            req_without_token_get = session.get(target, params=args_a_envoyer_copy)
            req_without_token_get_response = req_without_token_get.content

            if req_success.status_code == 302: #redirection
                if req_success.headers.get("Location") == req_with_bad_token.headers.get("Location"): #redirection vers meme page
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Mauvais jeton CSRF (" + token + ")")

                if req_success.headers.get("Location") == req_without_token.headers.get("Location"):
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Suppression jeton CSRF (" + token + ")")
                    
                if req_success.headers.get("Location") == req_without_token_get.headers.get("Location"):
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Passage par GET (" + token + ")")
            else:
                if len(req_success_response) == len(req_with_bad_token_response):
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Mauvais jeton CSRF (" + token + ")")

                if len(req_success_response) == len(req_without_token_response):
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Suppression du jeton CSRF (" + token + ")")

                if len(req_success_response) == len(req_without_token_get_response):
                    print(forme("found") + " Vulnérabilité trouvée : Méthode Passage par GET (" + token + ")")
            
    
    driver.quit()
    kill_proxy()
